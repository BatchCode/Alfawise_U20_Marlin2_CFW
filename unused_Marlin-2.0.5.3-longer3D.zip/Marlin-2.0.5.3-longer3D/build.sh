platformio run --verbose --environment alfawise_U30
